import { Link } from "react-router-dom";

export default function HeroSection() {
  return (
    <section className="text-center py-28 border-b border-zinc-900">

      <h1 className="text-5xl font-bold mb-6">
        Generate Synthetic Human Datasets
      </h1>

      <p className="text-zinc-400 text-lg max-w-2xl mx-auto mb-10">
        Privacy-safe, ready-to-train datasets for AI, CV and ML pipelines.
        No scraping. No legal risk. Instant structured delivery.
      </p>

      <div className="flex gap-6 justify-center">

        <Link
          to="/request"
          className="bg-blue-600 hover:bg-blue-500 px-8 py-4 rounded-xl font-semibold"
        >
          Create Dataset
        </Link>

        <Link
          to="/track"
          className="bg-zinc-800 hover:bg-zinc-700 px-8 py-4 rounded-xl font-semibold"
        >
          Track Order
        </Link>

      </div>

      <p className="text-sm text-zinc-500 mt-10">
        Used for AI training • Testing • Privacy research • Synthetic benchmarking
      </p>

    </section>
  );
}
