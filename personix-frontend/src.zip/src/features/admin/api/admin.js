const API = "http://127.0.0.1:8000";

// ---------------- METRICS ----------------
export async function getMetrics() {
  const res = await fetch(`${API}/admin/metrics`);
  if (!res.ok) throw new Error("Failed to fetch metrics");
  return res.json();
}

// ---------------- INSTANT ORDERS ----------------
export async function getInstantOrders() {
  const res = await fetch(`${API}/admin/dataset-orders`);
  if (!res.ok) throw new Error("Failed to fetch dataset orders");
  return res.json();
}

// ---------------- BULK ORDERS ----------------
export async function getBulkOrders() {
  const res = await fetch(`${API}/admin/bulk-orders`);
  if (!res.ok) throw new Error("Failed to fetch bulk orders");
  return res.json();
}

// ---------------- INVENTORY ----------------
export async function getInventory() {
  const res = await fetch(`${API}/admin/inventory`);
  if (!res.ok) throw new Error("Failed to fetch inventory");
  return res.json();
}


// const API = "http://127.0.0.1:8000/admin";

// // ---------------- LOGIN ----------------
// export async function adminLogin(password) {
//   const res = await fetch(`${API}/login`, {
//     method: "POST",
//     headers: { "Content-Type": "application/json" },
//     body: JSON.stringify({ password })
//   });

//   if (!res.ok) throw new Error("Invalid password");
//   return res.json();
// }

// // ---------------- METRICS ----------------
// export async function getMetrics() {
//   const res = await fetch(`${API}/metrics`);
//   if (!res.ok) throw new Error("Failed to fetch metrics");
//   return res.json();
// }

// // ---------------- INSTANT ORDERS ----------------
// export async function getInstantOrders() {
//   const res = await fetch(`${API}/dataset-orders`);
//   if (!res.ok) throw new Error("Failed to fetch dataset orders");
//   return res.json();
// }

// // ---------------- BULK ORDERS ----------------
// export async function getBulkOrders() {
//   const res = await fetch(`${API}/bulk-orders`);
//   if (!res.ok) throw new Error("Failed to fetch bulk orders");
//   return res.json();
// }

// // ---------------- INVENTORY ----------------
// export async function getInventory() {
//   const res = await fetch(`${API}/inventory`);
//   if (!res.ok) throw new Error("Failed to fetch inventory");
//   return res.json();
// }


// const API = "http://127.0.0.1:8000";

// // ---------------- DATASET ORDERS ----------------
// export async function getInstantOrders() {
//   const res = await fetch(`${API}/admin/dataset-orders`);
//   if (!res.ok) throw new Error("Failed to fetch dataset orders");
//   return res.json();
// }

// // ---------------- BULK ORDERS ----------------
// export async function getBulkOrders() {
//   const res = await fetch(`${API}/admin/bulk-orders`);
//   if (!res.ok) throw new Error("Failed to fetch bulk orders");
//   return res.json();
// }

// // ---------------- INVENTORY ----------------
// export async function getInventory() {
//   const res = await fetch(`${API}/admin/inventory`);
//   if (!res.ok) throw new Error("Failed to fetch inventory");
//   return res.json();
// }

// // ---------------- METRICS ----------------
// export async function getMetrics() {
//   const res = await fetch(`${API}/admin/metrics`);
//   if (!res.ok) throw new Error("Failed to fetch metrics");
//   return res.json();
// }
