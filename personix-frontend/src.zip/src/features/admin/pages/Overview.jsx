import StatCard from "../components/StatCard";

export default function Overview() {
  return (
    <div>

      <h1 className="text-3xl mb-8">Dashboard</h1>

      <div className="grid grid-cols-4 gap-6">

        <StatCard title="Total Orders" value="--" />
        <StatCard title="Pending" value="--" />
        <StatCard title="Completed" value="--" />
        <StatCard title="Bulk Requests" value="--" />

      </div>

    </div>
  );
}
