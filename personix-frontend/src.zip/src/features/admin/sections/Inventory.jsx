export default function Inventory() {
  return <div className="text-white">Inventory Stats Coming Here</div>;
}
