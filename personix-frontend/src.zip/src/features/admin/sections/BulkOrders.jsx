export default function BulkOrders() {
  return <div className="text-white">Bulk Orders Table Coming Here</div>;
}
