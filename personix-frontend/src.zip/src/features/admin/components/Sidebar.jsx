export default function SideBar() {
  return (
    <div className="text-white">
      Sidebar Loading...
    </div>
  );
}
