const API = "http://127.0.0.1:8000";

export async function checkBackend() {
  try {
    const res = await fetch(`${API}/health`, { method: "GET" });
    return res.ok;
  } catch {
    return false;
  }
}
