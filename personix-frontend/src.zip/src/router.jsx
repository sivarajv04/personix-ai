import { Routes, Route } from "react-router-dom";

import LandingPage from "./features/landing/pages/LandingPage.jsx";
import RequestPage from "./features/tools/pages/RequestPage.jsx";
import TrackPage from "./features/tools/pages/TrackPage.jsx";
import DownloadPage from "./features/tools/pages/DownloadPage.jsx";
import BulkPage from "./features/bulk/pages/BulkPage.jsx";
import AdminLogin from "./features/admin/pages/AdminLogin.jsx";
import Dashboard from "./features/admin/pages/Dashboard.jsx";
import AdminRoute from "./shared/auth/AdminRoute.jsx";

export default function Router() {
  return (
    <Routes>

      {/* Public */}
      <Route path="/" element={<LandingPage />} />
      <Route path="/request" element={<RequestPage />} />
      <Route path="/track" element={<TrackPage />} />
      <Route path="/download" element={<DownloadPage />} />
      <Route path="/bulk" element={<BulkPage />} />

      {/* Admin */}
      <Route path="/admin" element={<AdminLogin />} />

      <Route
        path="/admin/dashboard/*"
        element={
          <AdminRoute>
            <Dashboard />
          </AdminRoute>
        }
      />

    </Routes>
  );
}


// import { Routes, Route } from "react-router-dom";

// import LandingPage from "./features/landing/pages/LandingPage.jsx";
// import RequestPage from "./features/tools/pages/RequestPage.jsx";
// import TrackPage from "./features/tools/pages/TrackPage.jsx";
// import DownloadPage from "./features/tools/pages/DownloadPage.jsx";
// import BulkPage from "./features/bulk/pages/BulkPage.jsx";
// import AdminLogin from "./features/admin/pages/AdminLogin.jsx";
// import Dashboard from "./features/admin/pages/Dashboard.jsx";
// import AdminRoute from "./shared/auth/AdminRoute.jsx";

// export default function Router() {
//   return (
//     <Routes>
//       <Route path="/" element={<LandingPage />} />
//       <Route path="/request" element={<RequestPage />} />
//       <Route path="/track" element={<TrackPage />} />
//       <Route path="/download" element={<DownloadPage />} />
//       <Route path="/bulk" element={<BulkPage />} />
//       <Route path="/admin" element={<AdminLogin />}>
//         <Route path="dashboard" element={<AdminRoute><Dashboard /></AdminRoute>} />
//       </Route>
//       <Route path="/admin" element={<AdminLogin />} />
//       <Route
//         path="/admin/dashboard"
//         element={
//             <AdminRoute>
//             <Dashboard />
//             </AdminRoute>
//         }
//         />
//        </Routes>
//   );
// }
